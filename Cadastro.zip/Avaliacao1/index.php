<!DOCTYPE html>
<html lang="pt">
   <head>
   <meta charset="UTF-8"> 
       <title>Cadastros De Livros</title>
         
       <link rel="stylesheet" type="text/css" href="Estilo/Estilo.css">
   </head>
<body>
    <div class="Container">
       
        <h2>Cadastros De Livros </h2>
    
        <figure>
            <img class="Imagem"src="imagem/pensando.gif" alt="Pensador" >
        </figure>
    
         <div class="inclsao" id="inclusao">
            <form action="php/recebedados.php" method="get">
            
            <label for="nome"> Nome do Livro</label> <br>
            <input type="text" class="Campo" id="nome" name="Nome" placeholder="Nome do Livro" onChange="validarNome(event);"/>
                        
            <hr>
                
            <label for="nome"> Nome do Autor</label> <br>
            <input type="text" class="Campo" id="autor" name="autor" placeholder="Nome do Autor" onChange="validarAutor(event);"/>

             <hr>

            <label for="nome"> Numero de Paginas do Livro</label> <br>
            <input type="text" class="Campo" id="paginas" name="paginas" placeholder="Numero de Paginas do Livro" onChange="validarPaginas(event);"/> 

            <hr>

            <input type="submit" class="botao" id="botao" name="botao" Value="Enviar">
        </div>
    </div>
</body>
</html>