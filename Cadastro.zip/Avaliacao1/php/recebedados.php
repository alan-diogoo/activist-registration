<?php
$Nome = $_GET ["Nome"];
$autor = $_GET ["autor"];
$paginas = $_GET ["paginas"];

echo "nome =", $Nome, "<br />";
echo "autor =", $autor, "<br />";
echo "paginas =", $paginas, "<br />";

$hostName = "localhost";
$databaseName ="avaliacao1";
$databaseUser ="admin";
$databasePassword ="ifsp@1234";


$dbConnection = mysqli_connect($hostName,$databaseUser,$databasePassword,$databaseName);
if(mysqli_connect_error()){
    echo"<br />Erro na conexão com o banco de dados.";
    echo mysqli_connect_error();
}else{
    $query = "insert into ativistas (nome,autor,paginas) values ('".$Nome."','".$autor."','".$paginas."');";
    
    $res =mysqli_query($dbConnection,$query);

    if(mysqli_error($dbConnection)){
        echo "<br />";
        echo "prolemas ao gravar o registro no banco de dados:";
        echo mysqli_error($dbConnection);
    }else{
        echo "<h2> Registro armazenado com sucesso</h2> ";
    }
}

?>